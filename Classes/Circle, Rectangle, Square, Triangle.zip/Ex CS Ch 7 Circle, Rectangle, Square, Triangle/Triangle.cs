﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex_CS_Ch_7_Circle__Rectangle__Square__Triangle
{
    class Triangle
    {
        private double sideA { get; set; } = 1;
        private double sideB { get; set; } = 1;
        private double sideC { get; set; } = 1;

        public Triangle(double Side1, double Side2, double Side3)
        {
            sideA = Side1;
            sideB = Side2;
            sideC = Side3;
        }
        public void SetSideA(double Side1)
        {
            if (double.TryParse(Side1.ToString(), out Side1))
                sideA = Side1;
            else
                sideA = 1;
        }
        public void SetSideB(double Side2)
        {
            if (double.TryParse(Side2.ToString(), out Side2))
                sideB = Side2;
            else
                sideB = 1;
        }
        public void SetSideC(double Side3)
        {
            if (double.TryParse(Side3.ToString(), out Side3))
                sideC = Side3;
            else
                sideC = 1;
        }
        public double GetSideA() => sideA;
        public double GetSideB() => sideB;
        public double GetSideC() => sideC;
        public double GetArea()
        {
            double semiP = (sideA + sideB + sideC) / 2;
            double triarea = Math.Sqrt(semiP * (semiP - sideA) * (semiP - sideB) * (semiP - sideC));
            return triarea;
        }

        public double GetPerimeter() => sideA + sideB + sideC;
    }
}
