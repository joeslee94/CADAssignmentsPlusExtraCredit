﻿using System;

namespace Ex_CS_Ch_7_Circle__Rectangle__Square__Triangle
{
    class Program
    {
        static void Main(string[] args)
        {
            ////RECTANGLE
            //Console.WriteLine($"\RECTANGLE\n")
            //Rectangle rectangleTwo = new Rectangle(8, 10);
            //double beforelengthTwo = rectangleTwo.GetLength();
            //double beforewidthTwo = rectangleTwo.GetWidth();
            //Console.WriteLine($"The length of the rectangle is {beforelengthTwo} and the width is {beforewidthTwo} before being set.\n");

            //rectangleTwo.SetLength(10);
            //rectangleTwo.SetWidth(8);

            //double afterlengthTwo = rectangleTwo.GetLength();
            //double afterwidthTwo = rectangleTwo.GetWidth();
            //Console.WriteLine($"The length of the rectangle is {afterlengthTwo} and the width is {afterwidthTwo} after being set.\n");

            //double areaTwo = rectangleTwo.GetArea();
            //double perimeterTwo = rectangleTwo.GetPerimeter();
            //Console.WriteLine($"The area of the rectangle is {areaTwo} and the perimeter is {perimeterTwo}.\n");

            ////CIRCLE
            //Console.WriteLine($"\nCIRCLE\n")
            //Circle circleOne = new Circle(5);
            //double beforeradius = circleOne.GetRadius();
            //Console.WriteLine($"The initial input for the radius is {beforeradius}.\n");

            //circleOne.SetRadius(10);

            //double afterradius = circleOne.GetRadius();
            //Console.WriteLine($"The user input for the radius is {afterradius}.\n");

            //double circlearea = circleOne.GetArea();
            //double circlecircumference = circleOne.GetCircumference();
            //Console.WriteLine($"The area of the circle is {circlearea:N4}" +
            //    $" and the circumference is {circlecircumference:N4}.");

            ////SQUARE
            //Console.WriteLine($"\nSQUARE\n");
            //Square squareOne = new Square(7);
            //double initialside = squareOne.GetSide();
            //Console.WriteLine($"The initial value of a side is {initialside}\n");

            //squareOne.SetSide(10);

            //double afterside = squareOne.GetSide();
            //Console.WriteLine($"The value of a side has been set to {afterside}.\n");

            //double squareArea = squareOne.GetArea();
            //double squarePerimeter = squareOne.GetPerimeter();
            //Console.WriteLine($"The area of the square is {squareArea}" +
            //    $" and the perimeter is {squarePerimeter}.\n");

            ////TRIANGLE
            //Console.WriteLine($"\nTRIANGLE\n");
            //Triangle triangleOne = new Triangle(1, 1, 1);
            //double initialsideA = triangleOne.GetSideA();
            //double initialsideB = triangleOne.GetSideB();
            //double initialsideC = triangleOne.GetSideC();
            //Console.WriteLine($"Initially the triangle sides are as follows:\n" +
            //    $"Side 1: {initialsideA}\n" +
            //    $"Side 2: {initialsideB}\n" +
            //    $"Side 3: {initialsideC}\n");
           
            //triangleOne.SetSideA(6);
            //triangleOne.SetSideB(7);
            //triangleOne.SetSideC(8);

            //double aftersideA = triangleOne.GetSideA();
            //double aftersideB = triangleOne.GetSideB();
            //double aftersideC = triangleOne.GetSideC();
            //Console.WriteLine($"After setting the sides, the triangle sides are as follows:\n" +
            //    $"Side 1: {aftersideA}\n" +
            //    $"Side 2: {aftersideB}\n" +
            //    $"Side 3: {aftersideC}\n");

            //double triarea = triangleOne.GetArea();
            //double triperi = triangleOne.GetPerimeter();
            //Console.WriteLine($"The area of the triangle is {triarea}" +
            //    $" and the perimeter is {triperi}.");
        }
    }
}
