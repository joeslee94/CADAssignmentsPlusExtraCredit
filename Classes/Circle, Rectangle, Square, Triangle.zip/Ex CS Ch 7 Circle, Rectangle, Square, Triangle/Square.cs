﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex_CS_Ch_7_Circle__Rectangle__Square__Triangle
{
    class Square
    {
        private double side { get; set; } = 1;

        public Square(double Side) => side = Side;

        public void SetSide(double Side)
        {
            if (double.TryParse(Side.ToString(), out Side))
                side = Side;
            else
                side = 1;
        }

        public double GetSide() => side;
        public double GetArea() => side * side;
        public double GetPerimeter() => 4 * side;
    }
}
