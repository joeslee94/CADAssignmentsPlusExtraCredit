﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex_CS_Ch_7_Circle__Rectangle__Square__Triangle
{
    class Rectangle
    {
        private double length { get; set; } = 1;

        private double width { get; set; } = 1;

        public Rectangle(double Length, double Width)
        {
            length = Length;
            width = Width;
        }

        public void SetLength(double Length)
        {
            if (double.TryParse(Length.ToString(), out Length))
                length = Length;
            else
            {
                length = 1;
            }
        }

        public void SetWidth(double Width)
        {
            if (double.TryParse(Width.ToString(), out Width))
                width = Width;
            else
            {
                width = 1;
            }
        }
        public double GetLength()
        {
            return length;
        }
        public double GetWidth()
        {
            return width;
        }
        public double GetArea()
        {
            double area = length * width;
            return area;
        }

        public double GetPerimeter()
        {
            double perimeter = (2 * length) + (2 * width);
            return perimeter;
        }
    }
}
