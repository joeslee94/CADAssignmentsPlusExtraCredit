﻿using System;

namespace Lab_CS_Ch_7_Rectangle
{
    class Program
    {
        static void Main(string[] args)
        {
            //Rectangle without any values so it defaults to 1 and 1 (which are the default values)
            Rectangle rectangleTwo = new Rectangle();
            double beforelengthTwo = rectangleTwo.GetLength();
            double beforewidthTwo = rectangleTwo.GetWidth();
            Console.WriteLine($"The length of the rectangle is {beforelengthTwo} and the width is {beforewidthTwo} before being set.\n");

            //Setting rectangle length and width to different values
            rectangleTwo.SetLength(10);
            rectangleTwo.SetWidth(8);

            //Proving that the length and width has changed
            double afterlengthTwo = rectangleTwo.GetLength();
            double afterwidthTwo = rectangleTwo.GetWidth();
            Console.WriteLine($"\nThe length of the rectangle is {afterlengthTwo} and the width is {afterwidthTwo} after being set.\n");

            //Area and Perimeter of Rectangle
            double areaTwo = rectangleTwo.GetArea();
            double perimeterTwo = rectangleTwo.GetPerimeter();
            Console.WriteLine($"\nThe area of the rectangle is {areaTwo} and the perimeter is {perimeterTwo}.");
        }
    }
}
