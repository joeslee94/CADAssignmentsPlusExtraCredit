﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab_CS_Ch_7_Rectangle
{
    class Rectangle
    {
        private double length { get; set; }

        private double width { get; set; }
        public double GetArea()
        {
            double area = length * width;
            return area;
        }

        public double GetPerimeter()
        {
            double perimeter = (2 * length) + (2 * width);
            return perimeter;
        }

        public Rectangle(double Length = 1, double Width = 1)
        {
            length = Length;
            width = Width;
        }
        public double GetLength() => length;
        public double GetWidth() => width;

        public void SetLength(double Length)
        {
            if (double.TryParse(Length.ToString(), out Length) && Length > 0)
                length = Length;
            else
            {
                length = 1;
            }       
        }
    
        public void SetWidth(double Width)
        {
            if (double.TryParse(Width.ToString(), out Width) && Width > 0)
                width = Width;
            else
            {
                width = 1;
            }
        }
    }
}
